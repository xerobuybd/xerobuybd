import { useState } from 'react';

interface Product {
  id: number;
  name: string;
  price: string;
  priceRange: string;
  sizes: string;
  image: string;
  badge: string | null;
}

interface Category {
  id: string;
  icon: string;
  title: string;
  description: string;
  color: string;
}

// Product data
const products: { mens: Product[]; womens: Product[]; girls: Product[] } = {
  mens: [
    {
      id: 1,
      name: "Premium Cotton Boxer",
      price: "৳299 - ৳399",
      priceRange: "299-399",
      sizes: "M, L, XL, XXL",
      image: "https://images.unsplash.com/photo-1574126154517-d1e0d89e7344?w=400&h=500&fit=crop",
      badge: "New"
    },
    {
      id: 2,
      name: "Casual Pants",
      price: "৳799 - ৳1,299",
      priceRange: "799-1299",
      sizes: "30, 32, 34, 36, 38",
      image: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=400&h=500&fit=crop",
      badge: null
    },
    {
      id: 3,
      name: "Cotton T-Shirt",
      price: "৳399 - ৳699",
      priceRange: "399-699",
      sizes: "M, L, XL, XXL",
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=500&fit=crop",
      badge: "Hot"
    },
    {
      id: 4,
      name: "Premium Punjabi",
      price: "৳1,499 - ৳2,499",
      priceRange: "1499-2499",
      sizes: "M, L, XL, XXL",
      image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&h=500&fit=crop",
      badge: null
    },
    {
      id: 5,
      name: "Formal 3-Piece Set",
      price: "৳3,999 - ৳6,999",
      priceRange: "3999-6999",
      sizes: "M, L, XL, XXL",
      image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=400&h=500&fit=crop",
      badge: "Premium"
    }
  ],
  womens: [
    {
      id: 6,
      name: "Designer Kameez",
      price: "৳899 - ৳1,799",
      priceRange: "899-1799",
      sizes: "S, M, L, XL",
      image: "https://images.unsplash.com/photo-1583391733958-e04e9c8cb0a1?w=400&h=500&fit=crop",
      badge: "New"
    },
    {
      id: 7,
      name: "Casual Tops",
      price: "৳599 - ৳999",
      priceRange: "599-999",
      sizes: "S, M, L, XL",
      image: "https://images.unsplash.com/photo-1564257631407-4deb1f99d992?w=400&h=500&fit=crop",
      badge: null
    },
    {
      id: 8,
      name: "Cotton Saree",
      price: "৳1,999 - ৳4,999",
      priceRange: "1999-4999",
      sizes: "One Size",
      image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=400&h=500&fit=crop",
      badge: "Premium"
    }
  ],
  girls: [
    {
      id: 9,
      name: "Party Frock",
      price: "৳699 - ৳1,299",
      priceRange: "699-1299",
      sizes: "2-4Y, 4-6Y, 6-8Y, 8-10Y",
      image: "https://images.unsplash.com/photo-1519238263496-63f82a0148f8?w=400&h=500&fit=crop",
      badge: "New"
    },
    {
      id: 10,
      name: "Casual Dress",
      price: "৳499 - ৳899",
      priceRange: "499-899",
      sizes: "2-4Y, 4-6Y, 6-8Y, 8-10Y",
      image: "https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?w=400&h=500&fit=crop",
      badge: null
    }
  ]
};

const categories: Category[] = [
  {
    id: "mens",
    icon: "fa-male",
    title: "Men's Fashion",
    description: "Boxer, Pants, T-Shirts, Punjabi, 3-Piece",
    color: "from-blue-500 to-blue-600"
  },
  {
    id: "womens",
    icon: "fa-female",
    title: "Women's Fashion",
    description: "Kameez, Tops, Sarees, Dresses",
    color: "from-pink-500 to-pink-600"
  },
  {
    id: "girls",
    icon: "fa-child",
    title: "Girls' Collection",
    description: "Frocks, Dresses, Party Wear",
    color: "from-purple-500 to-purple-600"
  }
];

function orderProduct(productName: string, priceRange: string) {
  const message = `Hello Xerobuybd! I want to order: ${productName} (Price: ৳${priceRange})`;
  const whatsappUrl = `https://wa.me/8801731035808?text=${encodeURIComponent(message)}`;
  window.open(whatsappUrl, '_blank');
}

function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-white font-bold text-xl shadow-md">
              🛍️
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Xerobuybd</h1>
              <p className="text-xs text-gray-500 hidden sm:block">Premium Fashion Collection</p>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-blue-600 transition-colors">Home</button>
            <button onClick={() => scrollToSection('mens')} className="text-gray-700 hover:text-blue-600 transition-colors">Men's</button>
            <button onClick={() => scrollToSection('womens')} className="text-gray-700 hover:text-blue-600 transition-colors">Women's</button>
            <button onClick={() => scrollToSection('girls')} className="text-gray-700 hover:text-blue-600 transition-colors">Girls</button>
            <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-blue-600 transition-colors">Contact</button>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t">
            <div className="flex flex-col space-y-3">
              <button onClick={() => scrollToSection('home')} className="text-left text-gray-700 hover:text-blue-600 py-2">Home</button>
              <button onClick={() => scrollToSection('mens')} className="text-left text-gray-700 hover:text-blue-600 py-2">Men's</button>
              <button onClick={() => scrollToSection('womens')} className="text-left text-gray-700 hover:text-blue-600 py-2">Women's</button>
              <button onClick={() => scrollToSection('girls')} className="text-left text-gray-700 hover:text-blue-600 py-2">Girls</button>
              <button onClick={() => scrollToSection('contact')} className="text-left text-gray-700 hover:text-blue-600 py-2">Contact</button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}

function WhatsAppFloat() {
  return (
    <a
      href="https://wa.me/8801731035808?text=Hello%20Xerobuybd!%20I%20want%20to%20order"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"
    >
      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    </a>
  );
}

function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 via-purple-600 to-pink-500 pt-16">
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="relative z-10 text-center text-white px-4 py-20">
        <h2 className="text-4xl md:text-6xl font-bold mb-4">Welcome to Xerobuybd</h2>
        <p className="text-xl md:text-2xl mb-8 opacity-90">Your One-Stop Fashion Destination in Bangladesh</p>
        <button 
          onClick={() => document.getElementById('mens')?.scrollIntoView({ behavior: 'smooth' })}
          className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold text-lg hover:bg-gray-100 transition-all duration-300 hover:scale-105 shadow-lg"
        >
          Shop Now
        </button>
      </div>
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
}

function Categories() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-12">Shop by Category</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {categories.map((category) => (
            <div 
              key={category.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105 group"
            >
              <div className={`h-48 bg-gradient-to-br ${category.color} flex items-center justify-center`}>
                <svg className="w-20 h-20 text-white/80 group-hover:scale-110 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={
                    category.icon === 'fa-male' 
                      ? 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z'
                      : category.icon === 'fa-female'
                      ? 'M12 10a6 6 0 00-6 6v2h12v-2a6 6 0 00-6-6zm0-8a4 4 0 100 8 4 4 0 000-8z'
                      : 'M12 21a9 9 0 009-9c0-4.97-9-13-9-13S3 7.03 3 12a9 9 0 009 9z'
                  } />
                </svg>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{category.title}</h3>
                <p className="text-gray-600 mb-4">{category.description}</p>
                <button 
                  onClick={() => scrollToSection(category.id)}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 rounded-lg font-semibold hover:from-blue-600 hover:to-purple-600 transition-all duration-300"
                >
                  View Collection
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProductCard({ product }: { product: Product }) {
  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105 group">
      <div className="relative overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
        />
        {product.badge && (
          <span className={`absolute top-4 right-4 px-3 py-1 rounded-full text-sm font-semibold ${
            product.badge === 'Hot' 
              ? 'bg-red-500 text-white' 
              : product.badge === 'Premium'
              ? 'bg-purple-500 text-white'
              : 'bg-blue-500 text-white'
          }`}>
            {product.badge}
          </span>
        )}
      </div>
      <div className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{product.name}</h3>
        <p className="text-2xl font-bold text-blue-600 mb-2">{product.price}</p>
        <p className="text-gray-600 text-sm mb-4">Sizes: {product.sizes}</p>
        <button 
          onClick={() => orderProduct(product.name, product.priceRange)}
          className="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2"
        >
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
          <span>Order Now</span>
        </button>
      </div>
    </div>
  );
}

function ProductsSection({ 
  title, 
  products, 
  id 
}: { 
  title: string; 
  products: Product[]; 
  id: string 
}) {
  return (
    <section id={id} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-12">{title}</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Contact Us</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-white/20 transition-all duration-300">
            <svg className="w-16 h-16 mx-auto mb-4 text-green-400" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
            <h3 className="text-xl font-semibold mb-2">WhatsApp</h3>
            <p className="mb-4 text-gray-300">01731035808</p>
            <a 
              href="https://wa.me/8801731035808" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-semibold transition-all duration-300"
            >
              Chat Now
            </a>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-white/20 transition-all duration-300">
            <svg className="w-16 h-16 mx-auto mb-4 text-blue-400" fill="currentColor" viewBox="0 0 24 24">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
            <h3 className="text-xl font-semibold mb-2">Facebook</h3>
            <p className="mb-4 text-gray-300">Follow us on Facebook</p>
            <a 
              href="https://www.facebook.com/xerobuybd" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-semibold transition-all duration-300"
            >
              Visit Page
            </a>
            <p className="text-sm text-gray-400 mt-2">facebook.com/xerobuybd</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-white/20 transition-all duration-300">
            <svg className="w-16 h-16 mx-auto mb-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <h3 className="text-xl font-semibold mb-2">Location</h3>
            <p className="text-gray-300">Dhaka, Bangladesh</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <p className="mb-2">&copy; 2025 Xerobuybd. All Rights Reserved.</p>
        <p className="text-gray-400">Premium Fashion Store in Bangladesh</p>
      </div>
    </footer>
  );
}

export function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <WhatsAppFloat />
      <Hero />
      <Categories />
      <ProductsSection title="Men's Collection" products={products.mens} id="mens" />
      <ProductsSection title="Women's Collection" products={products.womens} id="womens" />
      <ProductsSection title="Girls' Collection" products={products.girls} id="girls" />
      <Contact />
      <Footer />
    </div>
  );
}
